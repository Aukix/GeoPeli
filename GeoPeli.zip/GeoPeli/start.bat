@echo off
chcp 65001 >nul
cd /d "%~dp0"
set NODE=node
if exist "%~dp0node\node.exe" set NODE="%~dp0node\node.exe"
start "" http://localhost:3000/host
%NODE% server.js
pause

// Pohjakartta suomenkielisillä nimillä (OpenFreeMap + MapLibre Leafletin kautta).
// Jos WebGL tai verkko ei toimi, tai WebGL-yhteys katoaa kesken pelin (heikot puhelimet), varalla on
// tavallinen OSM-rasterikartta (nimet paikallisella kielellä).
function osmFallback(map) {
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18, attribution: '© OpenStreetMap' }).addTo(map);
}

// Tienumerot (kilvet) ja isot tiet näkyviin jo kaukaa. MapLibren zoom on yksi pienempi kuin Leafletin (Leaflet 8 = MapLibre 7).
// Alkuperäisessä tyylissä kilvet alkavat vasta zoomilla 7–9 ja valtatiet ovat näkymättömän ohuita ennen zoomia 7.
function boostRoads(style, lowzSource) {
  const layer = id => style.layers.find(l => l.id === id);
  const width = (id, stops, minzoom) => {
    const l = layer(id);
    if (!l) return;
    l.paint = l.paint || {};
    l.paint['line-width'] = ['interpolate', ['exponential', 1.2], ['zoom'], ...stops];
    if (minzoom !== undefined) l.minzoom = minzoom;
  };
  // moottoritiet, valta- ja kantatiet (trunk/primary), seutu- ja yhdystiet (secondary/tertiary)
  width('road_motorway', [4, 0.8, 7, 1.5, 11, 2.9, 20, 18], 4);
  width('road_motorway_casing', [4, 1.1, 7, 2.2, 11, 4.0, 20, 22], 4);
  width('road_trunk_primary', [4, 0.7, 7, 1.4, 11, 2.9, 20, 18], 4);
  width('road_trunk_primary_casing', [4, 1.0, 6, 1.4, 7, 2.0, 11, 4.0, 20, 22], 4);
  width('road_secondary_tertiary', [5, 0.5, 8, 1.0, 11, 1.9, 20, 13], 5);
  // Tienumerokilvet esiin aiemmin. Tarkka laattadata (z7) sisältää tienumerot vain muutamalle tielle, joten zoomien 6–8
  // aikana kilvet piirretään z6-laatoista (ylisuurennettuina), ja vasta zoomista 8 alkaen tarkemmista laatoista.
  // Jos z6-lähdettä ei saatu, kilvet vain alkavat aiemmin.
  const shieldIds = ['highway-shield-non-us', 'highway-shield-us-interstate', 'road_shield_us'];
  for (const id of shieldIds) {
    const l = layer(id);
    if (!l) continue;
    l.layout = l.layout || {};
    l.layout['text-size'] = 11;
    l.layout['symbol-spacing'] = 150; // kilpi toistuu tiheämmin pitkillä teillä (alkup. 200)
    if (lowzSource) {
      const copy = JSON.parse(JSON.stringify(l));
      copy.id = id + '_lowz';
      copy.source = 'omt_lowz';
      copy.minzoom = 6;
      copy.maxzoom = 8;
      style.layers.splice(style.layers.indexOf(l) + 1, 0, copy);
      l.minzoom = Math.max(l.minzoom || 0, 8);
    } else {
      l.minzoom = id === 'road_shield_us' ? 6 : 5;
    }
  }
  // teiden nimet vähän aiemmin
  const names = layer('highway-name-major');
  if (names) names.minzoom = 11;
}

// opts.preserve: säilytä piirtopuskuri (isännän näytöllä; puhelimissa pois, koska syö muistia)
async function addBaseMap(map, opts = {}) {
  // Heikot laitteet (alle ~3 Gt muistia) saavat suoraan kevyen rasterikartan
  if (navigator.deviceMemory && navigator.deviceMemory <= 3 && !opts.preserve) return osmFallback(map);
  try {
    if (!window.maplibregl || !L.maplibreGL) throw new Error('maplibre puuttuu');
    const style = await (await fetch('https://tiles.openfreemap.org/styles/liberty', { signal: AbortSignal.timeout(8000) })).json();
    // nimi suomeksi, muuten latinalaisin kirjaimin, muuten paikallinen nimi
    const fi = ['coalesce', ['get', 'name:fi'], ['get', 'name:latin'], ['get', 'name']];
    // Vain nimitasot: tienumerokilvet (ref), talonnumerot yms. säilyttävät oman tekstikenttänsä
    for (const l of style.layers) {
      const tf = l.layout && l.layout['text-field'];
      if (tf && /"name/.test(JSON.stringify(tf))) l.layout['text-field'] = fi;
    }
    // Toinen lähde, joka käyttää vain z6-laattoja (tienumerot zoomeilla 6–8, ks. boostRoads)
    let lowz = false;
    try {
      const src = style.sources.openmaptiles;
      const tj = await (await fetch(src.url, { signal: AbortSignal.timeout(6000) })).json();
      if (tj.tiles && tj.tiles.length) {
        style.sources.omt_lowz = { type: 'vector', tiles: tj.tiles, minzoom: 6, maxzoom: 6 };
        lowz = true;
      }
    } catch (e) { /* ei haittaa: kilvet alkavat silti aiemmin */ }
    boostRoads(style, lowz);
    const gl = L.maplibreGL({ style, preserveDrawingBuffer: !!opts.preserve, attribution: '© OpenFreeMap © OpenMapTiles, data © OpenStreetMap' }).addTo(map);
    const g = gl.getMaplibreMap && gl.getMaplibreMap();
    // WebGL-yhteys katosi (muisti loppui / näytönohjain nollautui): vaihdetaan rasterikarttaan, ettei kartta jää jumiin
    if (g) {
      g.getCanvas().addEventListener('webglcontextlost', ev => {
        ev.preventDefault();
        try { map.removeLayer(gl); } catch (e) {}
        osmFallback(map);
      });
    }
    // Ensimmäinen piirto jää joskus tyhjäksi (kartta luotu ennen kuin koko on tiedossa): pakotetaan päivitys
    const refresh = () => {
      map.invalidateSize();
      if (g) { g.resize(); g.triggerRepaint(); }
    };
    [200, 800, 2000, 4000].forEach(t => setTimeout(refresh, t));
  } catch (e) {
    osmFallback(map);
  }
}

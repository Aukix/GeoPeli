// GeoPeli-palvelin: ei ulkoisia riippuvuuksia, pelkkä Node.js.
// Selaimet saavat tilapäivitykset SSE:llä (/events) ja lähettävät toiminnot POSTilla.
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const PORT = process.env.PORT || 3000;
const MAX_PLAYERS = 20;
let KEY = process.env.GOOGLE_MAPS_KEY || '';
const readKey = f => { try { return fs.readFileSync(path.join(__dirname, f), 'utf8').trim(); } catch { return ''; } };
if (!KEY) KEY = readKey('key.txt');
// Ilmainen vaihtoehto: Mapillary-token (mapillary.txt tai MAPILLARY_TOKEN)
const MLY = process.env.MAPILLARY_TOKEN || readKey('mapillary.txt');

// Lähiverkon osoitteet, oikeat kotiverkot (192.168 / 10. / 172.16-31) ensin
function lanUrls() {
  const rank = a => a.startsWith('192.168.') ? 0 : a.startsWith('10.') ? 1 : /^172\.(1[6-9]|2\d|3[01])\./.test(a) ? 2 : 3;
  return Object.values(os.networkInterfaces()).flat()
    .filter(i => i.family === 'IPv4' && !i.internal && !i.address.startsWith('169.254.'))
    .map(i => i.address).sort((a, b) => rank(a) - rank(b)).map(a => `http://${a}:${PORT}`);
}

const S = { phase: 'lobby', mode: 'classic', round: 0, rounds: 5, seconds: 60, deadline: 0, truth: null, results: null, view: null, maxKm: null, place: '' };
const players = new Map(); // id -> {id,name,score,guess}
const kicked = new Set();  // isännän poistamat pelaajat (eivät pääse takaisin samalla laitteella, ennen kuin palvelin käynnistetään uudelleen)
const clients = new Set();
let timer = null;

const pub = () => ({
  phase: S.phase, mode: S.mode, maxKm: S.maxKm,
  // Katukuvan lähtöpiste lähetetään pelaajille vain "liiku itse" -tilassa kierroksen aikana
  view: S.mode === 'roam' && S.phase === 'guessing' ? S.view : null,
  round: S.round, rounds: S.rounds, seconds: S.seconds,
  left: Math.max(0, S.deadline - Date.now()), // jäljellä oleva aika, ettei puhelinten kellot haittaa
  players: [...players.values()].map(p => ({ id: p.id, name: p.name, score: p.score, guessed: !!p.guess, away: !!p.awayStart })),
  results: S.results,
});
function broadcast() {
  const d = `data: ${JSON.stringify(pub())}\n\n`;
  for (const c of clients) c.write(d);
}

function haversineKm(a, b) {
  const R = 6371, r = x => x * Math.PI / 180;
  const dLat = r(b.lat - a.lat), dLng = r(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
// Oletus: GeoGuessr-tyylinen maailmankaava. Jos kierroksella on säde (maxKm, esim. pelkkä Suomi),
// pisteet laskevat nollaan säteen kohdalla: 5000 · (1 − km/maxKm)², ja sen yli menevä arvaus saa 0 p.
const scoreFor = km => S.maxKm
  ? (km >= S.maxKm ? 0 : Math.round(5000 * (1 - km / S.maxKm) ** 2))
  : Math.round(5000 * Math.exp(-km / 1492.7));

// Huijauksen esto: pelaajan sivu piilotettu/ei tarkennettuna kierroksen aikana (esim. Google Maps auki).
// Näytetään vain tuloksissa, ei vaikuta pisteisiin. Alle 3 s poissaolot ohitetaan (ilmoitusvarjo yms.).
function closeAway(p) {
  const d = Date.now() - p.awayStart;
  if (d >= 3000) { p.awayMs += d; p.awayCount++; }
  p.awayStart = 0;
}

function endRound() {
  clearTimeout(timer);
  for (const p of players.values()) if (p.awayStart) closeAway(p);
  const entries = [];
  const total = S.seconds * 1000;
  // Kokonaissijoitus ennen tätä kierrosta (sijoituksen muutosta varten)
  const rankIn = (score, pts) => 1 + [...pts].filter(x => x > score).length;
  const before = [...players.values()].map(p => p.score);
  for (const p of players.values()) {
    let dist = null, base = 0, speed = 0;
    if (p.guess) {
      dist = haversineKm(S.truth, p.guess);
      base = scoreFor(dist);
      // Nopeusbonus: enintään 1000 p, pienenee ajan kuluessa ja skaalautuu tarkkuuden mukaan,
      // ettei pelkkä nopea heitto tuota pisteitä.
      const frac = Math.max(0, Math.min(1, (S.deadline - p.guessAt) / total));
      speed = Math.round(1000 * frac * base / 5000);
    }
    entries.push({ id: p.id, name: p.name, lat: p.guess?.lat, lng: p.guess?.lng, dist, base, speed, closest: 0, points: 0, total: 0, awayMs: p.awayMs || 0, awayCount: p.awayCount || 0, p });
  }
  // Lähimmän arvauksen bonus +500 p
  const guessed = entries.filter(e => e.dist !== null && e.base > 0);
  if (guessed.length > 1) guessed.reduce((a, b) => (b.dist < a.dist ? b : a)).closest = 500;
  for (const e of entries) {
    e.prevRank = rankIn(e.p.score, before);
    e.points = e.base + e.speed + e.closest;
    e.p.score += e.points;
    e.total = e.p.score;
  }
  const after = [...players.values()].map(p => p.score);
  for (const e of entries) {
    e.rank = rankIn(e.total, after);
    e.delta = S.round > 1 ? e.prevRank - e.rank : 0; // positiivinen = nousi; 1. kierroksella ei muutosta
    delete e.p; delete e.prevRank;
  }
  entries.sort((a, b) => b.points - a.points);
  S.results = { truth: S.truth, place: S.place, entries };
  S.phase = 'results';
  S.deadline = 0;
  broadcast();
}

function startRound(lat, lng) {
  S.round++;
  S.truth = { lat, lng };
  S.results = null;
  S.phase = 'guessing';
  S.deadline = Date.now() + S.seconds * 1000;
  for (const p of players.values()) Object.assign(p, { guess: null, awayStart: 0, awayMs: 0, awayCount: 0 });
  clearTimeout(timer);
  timer = setTimeout(endRound, S.seconds * 1000 + 500);
  broadcast();
}

function reset() {
  clearTimeout(timer);
  Object.assign(S, { phase: 'lobby', round: 0, deadline: 0, truth: null, results: null });
  for (const p of players.values()) { p.score = 0; p.guess = null; }
  broadcast();
}

// Syke: tila lähetetään 10 s välein, jotta selaimet huomaavat katkenneen yhteyden ja yhdistävät uudelleen
setInterval(() => { if (clients.size) broadcast(); }, 10000);

const isLocal = req => ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress);
const num = (v, lo, hi) => Number.isFinite(+v) && +v >= lo && +v <= hi;

const routes = {
  'POST /api/host/kick': b => {
    const p = players.get(b.id);
    if (!p) return [404, 'Pelaajaa ei löydy'];
    players.delete(b.id);
    kicked.add(String(b.id));
    // jos kierros on käynnissä ja kaikki jäljellä olevat ovat arvanneet, kierros päättyy
    if (S.phase === 'guessing' && players.size && [...players.values()].every(x => x.guess)) endRound(); else broadcast();
    return [200, {}];
  },
  'POST /api/join': b => {
    const name = String(b.name || '').trim().slice(0, 20);
    if (!b.id || !name) return [400, 'Nimi puuttuu'];
    if (kicked.has(String(b.id))) return [403, 'Isäntä on poistanut sinut pelistä'];
    const p = players.get(b.id);
    if (p) { if (S.phase === 'lobby') p.name = name; } // nimen voi vaihtaa vain aulassa
    else if (players.size >= MAX_PLAYERS) return [403, 'Peli on täynnä'];
    else players.set(b.id, { id: String(b.id).slice(0, 40), name, score: 0, guess: null });
    broadcast();
    return [200, {}];
  },
  'POST /api/away': b => {
    const p = players.get(b.id);
    if (!p) return [404, 'Tuntematon pelaaja'];
    if (b.away && S.phase === 'guessing' && !p.guess && !p.awayStart) p.awayStart = Date.now();
    else if (!b.away && p.awayStart) closeAway(p);
    else return [200, {}];
    broadcast();
    return [200, {}];
  },
  'POST /api/guess': b => {
    const p = players.get(b.id);
    if (!p || S.phase !== 'guessing' || p.guess) return [409, 'Ei voi arvata nyt'];
    if (!num(b.lat, -90, 90) || !num(b.lng, -180, 180)) return [400, 'Virheellinen sijainti'];
    p.guess = { lat: +b.lat, lng: +b.lng };
    p.guessAt = Date.now();
    if ([...players.values()].every(x => x.guess)) endRound(); else broadcast();
    return [200, {}];
  },
  // Isäntätoiminnot: vain samalta koneelta (localhost)
  'POST /api/host/settings': b => {
    if (S.phase !== 'lobby') return [409, 'Vain aulassa'];
    if (num(b.rounds, 1, 20)) S.rounds = Math.round(+b.rounds);
    if (num(b.seconds, 10, 600)) S.seconds = Math.round(+b.seconds);
    if (b.mode === 'classic' || b.mode === 'roam') S.mode = b.mode;
    broadcast();
    return [200, {}];
  },
  'POST /api/host/round': b => {
    if (S.phase === 'guessing') return [409, 'Kierros on käynnissä'];
    if (!num(b.lat, -90, 90) || !num(b.lng, -180, 180)) return [400, 'Virheellinen sijainti'];
    if (!players.size) return [409, 'Ei pelaajia'];
    if (!['google', 'mapillary'].includes(b.provider) || !b.id || !b.key) return [400, 'Kuvalähde puuttuu'];
    S.place = typeof b.place === 'string' ? b.place.slice(0, 80) : '';
    S.maxKm = num(b.maxKm, 50, 20000) && b.maxKm ? +b.maxKm : null;
    S.view = { provider: b.provider, id: String(b.id), key: String(b.key) };
    startRound(+b.lat, +b.lng);
    return [200, {}];
  },
  'POST /api/host/end': () => { if (S.phase === 'guessing') endRound(); return [200, {}]; },
  'POST /api/host/final': () => { S.phase = 'final'; broadcast(); return [200, {}]; },
  'POST /api/host/reset': () => { reset(); return [200, {}]; },
};

const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.png': 'image/png', '.svg': 'image/svg+xml', '.json': 'application/json' };

http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  const key = `${req.method} ${url.pathname}`;

  if (url.pathname === '/events') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    res.write(`data: ${JSON.stringify(pub())}\n\n`);
    clients.add(res);
    req.on('close', () => clients.delete(res));
    return;
  }
  if (url.pathname === '/api/info') {
    const local = isLocal(req);
    return json(res, 200, {
      urls: lanUrls(), google: local ? KEY : undefined, mapillary: local ? MLY : undefined, max: MAX_PLAYERS,
      view: local && S.phase === 'guessing' ? S.view : undefined, // isäntäsivun päivitys kesken kierroksen
    });
  }
  if (routes[key]) {
    if (url.pathname.startsWith('/api/host/') && !isLocal(req)) return json(res, 403, { error: 'Vain isännälle' });
    let raw = '';
    req.on('data', c => { raw += c; if (raw.length > 1e4) req.destroy(); });
    req.on('end', () => {
      let body = {};
      try { body = raw ? JSON.parse(raw) : {}; } catch { return json(res, 400, { error: 'Virheellinen JSON' }); }
      const [code, out] = routes[key](body);
      json(res, code, typeof out === 'string' ? { error: out } : out);
    });
    return;
  }

  // Staattiset tiedostot
  const map = { '/': 'player.html', '/host': 'host.html' };
  const file = map[url.pathname] || url.pathname.slice(1);
  const full = path.join(__dirname, 'public', path.normalize(file));
  if (!full.startsWith(path.join(__dirname, 'public'))) { res.writeHead(403); return res.end(); }
  fs.readFile(full, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Ei löytynyt'); }
    // Kirjastot (vendor) eivät muutu: puhelimet saavat välimuistittaa ne
    res.writeHead(200, { 'Content-Type': MIME[path.extname(full)] || 'application/octet-stream',
      'Cache-Control': url.pathname.startsWith('/vendor/') ? 'public, max-age=604800' : 'no-cache' });
    res.end(data);
  });
}).listen(PORT, '0.0.0.0', () => {
  console.log(`\nGeoPeli käynnissä.\n  Isäntä (videotykki): http://localhost:${PORT}/host`);
  for (const u of lanUrls()) console.log(`  Pelaajat puhelimella: ${u}`);
  if (!KEY && !MLY) console.log('\n  HUOM: kuvapalvelun avainta ei löytynyt (mapillary.txt tai key.txt).');
});

function json(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(obj));
}
